import axios from 'axios';

// Create axios instance with default config
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor for authentication
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Authentication service
export const authService = {
  login: async (username: string, password: string) => {
    const formData = new FormData();
    formData.append('username', username);
    formData.append('password', password);
    
    const response = await api.post('/auth/login', formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });
    
    if (response.data.access_token) {
      localStorage.setItem('token', response.data.access_token);
    }
    
    return response.data;
  },
  
  logout: () => {
    localStorage.removeItem('token');
  },
  
  getCurrentUser: async () => {
    return api.get('/auth/me');
  },
};

// Agent service
export const agentService = {
  getAgents: async (params = {}) => {
    return api.get('/agents', { params });
  },
  
  getAgent: async (id: number) => {
    return api.get(`/agents/${id}`);
  },
  
  createAgent: async (agentData: any) => {
    return api.post('/agents', agentData);
  },
  
  updateAgent: async (id: number, agentData: any) => {
    return api.put(`/agents/${id}`, agentData);
  },
  
  deleteAgent: async (id: number) => {
    return api.delete(`/agents/${id}`);
  },
  
  startAgent: async (id: number) => {
    return api.post(`/agents/${id}/start`);
  },
  
  stopAgent: async (id: number) => {
    return api.post(`/agents/${id}/stop`);
  },
  
  pauseAgent: async (id: number) => {
    return api.post(`/agents/${id}/pause`);
  },
};

// Task service
export const taskService = {
  getTasks: async (params = {}) => {
    return api.get('/tasks', { params });
  },
  
  getTask: async (id: number) => {
    return api.get(`/tasks/${id}`);
  },
  
  createTask: async (taskData: any) => {
    return api.post('/tasks', taskData);
  },
  
  updateTask: async (id: number, taskData: any) => {
    return api.put(`/tasks/${id}`, taskData);
  },
  
  deleteTask: async (id: number) => {
    return api.delete(`/tasks/${id}`);
  },
  
  assignTask: async (taskId: number, agentId: number) => {
    return api.post(`/tasks/${taskId}/assign/${agentId}`);
  },
};

// Tracking service
export const trackingService = {
  getAgentLogs: async (agentId: number, limit = 100) => {
    return api.get(`/tracking/agents/${agentId}/logs`, { params: { limit } });
  },
  
  getTaskLogs: async (taskId: number, limit = 100) => {
    return api.get(`/tracking/tasks/${taskId}/logs`, { params: { limit } });
  },
  
  updateAgentStatus: async (agentId: number, status: string) => {
    return api.post(`/tracking/agents/${agentId}/status/${status}`);
  },
  
  updateTaskProgress: async (taskId: number, progress: number, status?: string) => {
    return api.post(`/tracking/tasks/${taskId}/progress/${progress}`, { task_status: status });
  },
  
  connectWebSocket: (userId: number, onMessage: (data: any) => void) => {
    const wsUrl = `${process.env.REACT_APP_WS_URL || 'ws://localhost:8000'}/tracking/ws/${userId}`;
    const ws = new WebSocket(wsUrl);
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      onMessage(data);
    };
    
    return ws;
  },
};

// Analytics service
export const analyticsService = {
  getDashboardData: async () => {
    return api.get('/analytics/dashboard');
  },
  
  getAgentStats: async () => {
    return api.get('/analytics/agents/stats');
  },
  
  getTaskStats: async () => {
    return api.get('/analytics/tasks/stats');
  },
  
  getAgentPerformance: async (agentId: number) => {
    return api.get(`/analytics/agents/${agentId}/performance`);
  },
};

// User service
export const userService = {
  getUsers: async (params = {}) => {
    return api.get('/users', { params });
  },
  
  getUser: async (id: number) => {
    return api.get(`/users/${id}`);
  },
  
  createUser: async (userData: any) => {
    return api.post('/users', userData);
  },
  
  updateUser: async (id: number, userData: any) => {
    return api.put(`/users/${id}`, userData);
  },
  
  deleteUser: async (id: number) => {
    return api.delete(`/users/${id}`);
  },
};

export default api;
